function postLogout() {}
module.exports = postLogout
